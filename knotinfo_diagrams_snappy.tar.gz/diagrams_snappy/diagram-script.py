#!/usr/bin/env/python
# This script was saved by SnapPy on Tue Jun 18 09:37:15 2019.

f= open("/Users/livingst/Documents/KnotTable/SnappyDiagrams/PDnotation.txt","r")

contents=f.read()

contents[1]
#'['

eval(contents.split()[1])
#[[4, 2, 5, 1], [8, 6, 1, 5], [6, 3, 7, 4], [2, 7, 3, 8]]

eval(contents.split()[2976])
#[[1, 11, 2, 10], [3, 13, 4, 12], [20, 6, 21, 5], [16, 8, 17, 7], [18, 10, 19, 9], [11, 3, 12, 2], [13, 23, 14, 22], [15, 1, 16, 24], [8, 18, 9, 17], [4, 20, 5, 19], [6, 22, 7, 21], [23, 15, 24, 14]]

eval(contents.split()[2977])

x=0

x=0
while(x<50):
    K=Link(eval(contents.split()[x]))
    K.view().save_as_svg('/Users/livingst/Documents/KnotTable/SnappyDiagrams/knot' + str(x) + '.svg','color')
    x +=1
    
